module.exports = {
        // url : 'mongodb://aeneas:tooclosetothesun@ds039195.mlab.com:39195/atlas'
        url : 'mongodb://localhost:27017/atlas' 
} 

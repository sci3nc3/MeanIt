# Meanit

## Quick-instal.

Verify that you have node > 6 and npm > 3.3.10

````
git clone git@github.com:radubl/meanit.git 
cd meanit
npm install -g bower
npm install
bower install
nodemon
```
go to `localhost:8080`

## App structure

`package.json` - contains npm (server-side) dependencies.
`bower.json` - contains fornt-end dependencies
--- for add-on libraries, use one or the other for consistency.

`server.js` powers up the webserver on port 8080 through express.
  - uses the login information in 'config/db.js' to connect to our production mongo instance.
  - uses the routing configuration under `app.routes.js` to serve the API and the static index.html file.

the`public` folder contains our front-end static assets, canonically distributed across `img, css, fonts, libs, js folders`.
it is worth mentioning that the `js` folder is split angular.js style into `directives, controllers and services`.

`app.js` bootstraps all the angular elements. (make sure that all js libraries are imported under index.html
`appRoutes.js` dictates the routing configuration of givee and serves the html files under `views` for each routing configuration, alongside a bespoke controller.

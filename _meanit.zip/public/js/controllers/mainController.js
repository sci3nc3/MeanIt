function mainController($scope, Page) {
    $scope.Page = Page;
}